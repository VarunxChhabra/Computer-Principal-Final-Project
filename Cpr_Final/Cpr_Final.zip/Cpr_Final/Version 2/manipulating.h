//MANIPULATING MODULE HEADER

#define _MANIPUALTING_H_
#include <stdio.h>
#include <string.h>
void manipulating(void);
