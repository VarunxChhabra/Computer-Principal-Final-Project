// CONVERTING MODULE HEADER
#ifndef _FUNDAMENTALS_H
#define _FUNDAMENTALS_H
#include <stdio.h>   //including stdio.h
#include <stdlib.h> //including stdlib.h
#include <string.h> // including string.h
void fundamentals(void);
#endif