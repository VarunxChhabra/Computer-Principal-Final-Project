//MANIPULATING MODULE HEADER

#define _MANIPUALTING_H_
#include <stdio.h>  //including stdio.h
#include <string.h> // including string.h
void manipulating(void);
