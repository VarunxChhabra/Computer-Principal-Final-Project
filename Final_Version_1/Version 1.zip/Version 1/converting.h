// CONVERTING MODULE HEADER
#ifndef _CONVERTING_H_
#define _CONVERTING_H_
#include <stdio.h>  //including stdio.h
#include <string.h> //including string.h
#include <stdlib.h> //including stdlib.h
void converting(void);
#endif